<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class horario extends Model
{
    protected $table = 'horario';
    public $timestamps = false;

    protected $fillable = array('turno','horario_de_entrada','horario_de_saida');
}
