<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class departamento extends Model
{
    protected $table = 'departamento';
    public $timestamps = false;
    protected $fillable = array('nome','nome_do_utilizador','chefe_do_departamento','data','');

}
