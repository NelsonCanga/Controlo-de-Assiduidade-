<?php

namespace App\Http\Controllers;

use App\empresa;
use Illuminate\Http\Request;

class empresaController extends Controller
{
    public function novaEmpresa(Request $request){
        $empresa =  new empresa();

    }
}
