<?php
namespace App\Http\Controllers;
 use Illuminate\Support\Facades\DB;
 use Illuminate\Http\Request;
 use App\Funcionario;
 use Illuminate\Support\Facades\Redirect;
 use Illuminate\Support\Facades\Session;






 class funcionarioController extends Controller {
     /**
      * @param Request $request
      *
      */
     public function novo(){
         return view('registoFuncionario');
     }
     public function enviar(Request $request){
              $funcionario = new Funcionario();
         $funcionario->create( $request->all());
         session :: flash('mensagem_sucesso','Funcionario Cadastrado com Sucesso');

         return  Redirect::to('novo');

 		}
      public function editar(Request $request,$id){
          $funcionario = DB :: find();

          return  Redirect::to('novo');
      }

 		public function listaFuncionario(){
          $funcionario = funcionario:: get();
          return  view('listafuncionario')->with('funcionario',$funcionario);
        }

        public function pesquisaFuncionario(Request $request){
            $nome = $request->get('nome');
            $funcionario = DB :: table('funcionario')->where('nome','LIKE','%'.$nome.'%')->paginate(5);
            return  view('listafuncionario')->with('funcionario',$funcionario);
         }


  }
