<?php
/**
 * Created by PhpStorm.
 * User: Nelson dos Santos
 * Date: 09/08/2018
 * Time: 13:29
 */

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\horario;

use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;
use App\Extensions\MongoSessionHandler;

class horarioController
{
     public function novoHorario(Request $reques){
         $horario = new horario();
         $horario->create($reques->all());
         session :: flash('mensagem_sucesso','Horário Cadastrado com Sucesso');
        return redirect :: to ('horario');

     }
}