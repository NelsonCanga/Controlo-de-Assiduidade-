<?php
/**
 * Created by PhpStorm.
 * User: Nelson dos Santos
 * Date: 09/08/2018
 * Time: 08:22
 */

namespace App\Http\Controllers;


use App\departamento;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;



class departamentoController extends Controller{
     public function novoDepartamento(Request $reques){

         $departamento = new departamento();
         $departamento->create($reques->all());
         session :: flash('mensagem_sucesso','Departamento Cadastrado com Sucesso');

         return  Redirect::to('departamento');

     }

}