<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class empresa extends Model
{
    protected $table = 'empresaController';
    public $timestamps = false;

    protected $fillable = array('nome','logo','espaco_fiscal');
}
