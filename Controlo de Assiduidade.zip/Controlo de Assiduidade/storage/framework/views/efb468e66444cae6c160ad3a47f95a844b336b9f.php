<?php $__env->startSection('conteudo'); ?>

<?php echo e(Form::open(['route' => ''])); ?>


<!-- ROW 1 -->
<div class="row marow service-box">
    <div class="col-md-12 ">
        <!-- BLOCK START-->
        <div class="panel panel- panel-info">   
            <div class="panel-heading">
                <h1 class="panel-title">Novo Utente</h1>
            </div>
            <div class="panel-body">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="nome">Nome:</label>
                        <?php echo e(Form::text('nome', '', array('placeholder'=>'Nome do Utente','class'=> 'form-control'))); ?>

                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="password">Senha:</label>
                        <?php echo e(Form::password('nome',['class' => 'form-control','placeholder'=>'informe a Senha'])); ?>

                    </div>
                </div>
            </div>

            <div class="form-actions right margin-bottom-10">
                <?php echo e(Form::submit('Salvar',['class' => 'btn blue '])); ?>

                 <?php echo e(Form::reset('Limpar',['class' => 'btn default'])); ?>

            </div>
        </div>

    </div>

</div>

<?php echo e(Form::close()); ?>





<?php echo $__env->make('menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>