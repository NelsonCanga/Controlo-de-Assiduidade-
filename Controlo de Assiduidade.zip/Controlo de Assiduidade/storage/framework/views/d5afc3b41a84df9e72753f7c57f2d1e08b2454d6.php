<?php $__env->startSection('conteudo'); ?>
    <div class="row marow service-box">
        <div class="col-md-12 ">
            <!-- BLOCK START-->
            <div class="panel panel- panel-info">
                <div class="panel-heading">
                    <h1 class="panel-title">Lista de funcionarios </h1>
                </div>
                <div class="panel-body">
                    <div class="card mb-3">
                        <div class="card-header">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                    <tr>
                                        <div class="col-sm-12 input-group">
                                            <form method="post" action="<?php echo e(url('pesquisar')); ?>" >
                                                <?php echo e(csrf_field()); ?>

                                                <input type="search" required id="nome" name="nome" class="form-control" style="width: 250px;" placeholder="pesquise..">
                                                <button class="btn btn-default" type="submit">Pesquise</button>
                                            </form>
                                        </div>
                                            <div class="col-sm-12">



                                        </div>

                                        <br>
                                        <th>id funcionario</th>
                                        <th>Nome Funcionario</th>
                                          <th>Genero</th>
                                        <th>Departamento</th>
                                        <th>Horario</th>
                                        <th>Editar</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $funcionario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $funcionario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($funcionario->id_funcionario); ?></td>
                                        <td><?php echo e($funcionario->nome); ?></td>
                                        <td><?php echo e($funcionario->genero); ?></td>
                                        <td><?php echo e($funcionario->departamento); ?></td>
                                        <td><?php echo e($funcionario->horario); ?></td>
                                        <td><a class="btn btn-instagram" href="editar/<?php echo e($funcionario->id_funcionario); ?>">Editar</a></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>