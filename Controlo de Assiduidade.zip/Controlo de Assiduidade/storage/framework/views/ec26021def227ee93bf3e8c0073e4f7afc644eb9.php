<?php $__env->startSection('conteudo'); ?>


    <div class="row marow service-box">
        <div class="col-md-12 ">
            <!-- BLOCK START-->
             
            <div class="panel panel- panel-info">
                <div class="panel-heading">
                    <h1 class="panel-title">Novo Horario </h1>
                </div>
                <div class="panel-body">
                    <?php if(session()->has('mensagem_sucesso')): ?>
                        <div class=" alert alert-success "><?php echo e(session('mensagem_sucesso')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="col-md-6">
                        <?php echo e(Form::open(['url' => 'horario'])); ?>

                            <div class="form-group">
                                <label for="turno">Turno</label>
                                <select type="text" name="turno" class="form-control" id="turno" placeholder="Insira o turno" value="" required>
                                    <option value=""></option>
                                    <option value="Diurno">Diurno</option>
                                    <option value="Noturno">Noturno</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="horario_de_entrada">Horário de Entrada</label>
                                <input type="time" required id="horario_de_entrada" name="horario_de_entrada">
                            </div>
                            <div class="form-group">
                                <label for="horario_de_saida">Horário de Saida</label>
                                <input type="time" id="horario_de_saida" name="horario_de_saida" required>
                            </div>
                            <div class="form-group">
                                <button type="reset" class="btn btn-danger btn-lg float-right">Limpar</button>
                                <button type="submit" class="btn btn-success btn-lg float-right">Registar</button>

                                </div>
                        <?php echo e(Form::close()); ?>


                    </div>

                </div>

            </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>