<?php $__env->startSection('conteudo'); ?>
    <div class="row marow service-box">
        <div class="col-md-12 ">
            <!-- BLOCK START-->
            <div class="panel panel- panel-info">
                <div class="panel-heading">
                    <h1 class="panel-title">Novo Departamento </h1>
                </div>
                <div class="panel-body">
                    <?php if(session()->has('mensagem_sucesso')): ?>
                        <div class=" alert alert-success  "><?php echo e(session('mensagem_sucesso')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="col-md-6">

                    <?php echo e(Form::open(['url' => 'departamento'])); ?>

        <div class="form-group">
            <label for="Nome">Chefe de departamento</label>
            <input type="text" name="nome" class="form-control" id="nome" placeholder="Insira o nome do chef de departamento" value="" required>
            <div class="invalid-feedback">
                É necessario o nome do chef de departamento.
            </div>
        </div>

        <div class="form-group">
            <label for="exampleInputName">Nome do departamento</label>
            <input id="departamento" name="departamento" placeholder="Nome do departameno" class="form-control input-md" type="name" required="">
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-success btn-lg float-right">Registar</button>
        </div>
    <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>