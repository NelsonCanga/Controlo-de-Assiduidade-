@extends('menu')
@section('conteudo')
<!-- ROW 1 -->
<div class="row marow service-box">
    <div class="col-md-12 ">
        <!-- BLOCK START-->
        <div class="panel panel- panel-info">
            <div class="panel-heading">
                <h1 class="panel-title">Novo Funcionario </h1>
            </div>
            <div class="panel-body">
                 @if(session()->has('mensagem_sucesso'))
                    <div class=" alert alert-success">{{session('mensagem_sucesso')}}
                    </div>
                @endif
                <div class="col-md-6">
                        {{ Form::open(['url' => 'enviar']) }}
                        <div class="form-group">
                            <label for="Nome">Nome</label>
                            <input type="text" name="nome" class="form-control" id="nome" placeholder="Insira o nome" value="" required>
                            <div class="invalid-feedback">
                                É necessario o nome.
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputName">Gênero</label>
                            <select id="genero" name="genero" class="form-control" required="">
                                <option value=""></option>
                                <option value="Mascolino">Masculino</option>
                                <option value="Femenino">Femenino</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputName">Nascimento</label>
                            <input id="nascimento" name="nascimento" placeholder="DD/MM/AAAA" class="form-control input-md" required="" type="date" maxlength="10" OnKeyPress="formatar('##/##/####', this)" onBlur="showhide()" required="">
                        </div>
                        <div class="form-group">
                            <label for="departamento">Departamento</label>
                            <select  id="departamento" name="departamento" class="form-control" required>
                                <option value="directoria">Directoria</option>
                                <option value="operacao">Operação</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputName">Horário</label>
                            <input id="horario" name="horario" placeholder="--:--" class="form-control input-md" type="hora" required="">
                        </div>

                        <div class="form-actions right margin-bottom-10">
                            <button type="reset" class="btn btn-danger btn-lg float-right">Limpar</button>
                            <button type="submit" class="btn btn-success btn-lg float-right">Salvar</button>

            </div>

                    {{Form::close()}}
        </div>

    </div>

</div>


</div>
</div>



@endsection





