<!DOCTYPE>
<html>
<head>
 <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
    <link href="offcanvas.css" rel="stylesheet">
   
  <link href="dashboard.css" rel="stylesheet">
</head>
    <body>
        <div class="jumbotron ">
        <div class="container py-5" >
           
          
                 

               <div class="row">
                <div class="col-md-6 offset-md-3">
   <!-- form card register -->
                    <div class="card card-outline-secondary">
                        <div class="card-header">
                            <h3 class="mb-0">Criar departamento</h3>
                        </div>
                        <div class="card-body">
                            <form class="form" role="form" autocomplete="off">
                                <div class="form-group">
                                    <label for="Nome">Chefe de departamento</label>
                                    <input type="text" name="nome" class="form-control" id="nome" placeholder="Insira o nome do chef de departamento" value="" required>
                                    <div class="invalid-feedback">
                                      É necessario o nome do chef de departamento.
                                    </div>
                                </div>
                               
                                <div class="form-group">
                                     <label for="exampleInputName">Nome do departamento</label>  
                                    <input id="departamento" name="departamento" placeholder="Nome do departameno" class="form-control input-md" type="name" required="">
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-success btn-lg float-right">Registar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                   </div>
            </div>
                    <!-- /form card register -->

 
        
    


</div>
        </div>
    
    
<script src="jq/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>  
 

</body>

</html>