<!DOCTYPE>
<html>
<head>
 <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
    <link href="offcanvas.css" rel="stylesheet">
   
  <link href="dashboard.css" rel="stylesheet">
</head>
    <body>
        <div class="jumbotron ">
        <div class="container py-5" >
           
          
                 

               <div class="row">
                <div class="col-md-6 offset-md-3">
   <!-- form card register -->
                    <div class="card card-outline-secondary">
                        <div class="card-header">
                            <h3 class="mb-0">Criar horário</h3>
                        </div>
                        <div class="card-body">
                            {{  Form ::open("url('')")}}
                            <form class="form" role="form" autocomplete="off">
                                <div class="form-group">
                                    <label for="Nome">Turno</label>
                                    <select type="text" name="turno" class="form-control" id="turno" placeholder="Insira o turno" value="" required>
                                       <option value=""></option>
                                      <option value="Diurno">Diurno</option>
                                      <option value="Noturno">Noturno</option>
                                    </select>
                                </div>
                               
                                <div class="form-group">
                                     <label for="exampleInputName">Horário de entrada</label>  
                                    <input id="entrada" name="entrada" placeholder="--:--" class="form-control input-md" type="hora" required="">
                                </div>
                                <div class="form-group">
                                     <label for="exampleInputName">Horário de saida</label>  
                                    <input id="saida" name="saida" placeholder="--:--" class="form-control input-md" type="hora" required="">
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-success btn-lg float-right">Registar</button>
                                </div>
                                {{  Form ::close()}}
                            </form>
                        </div>
                    </div>
                   </div>
            </div>
                    <!-- /form card register -->

 
        
    


</div>
        </div>
    
    
<script src="jq/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>  
 

</body>

</html>