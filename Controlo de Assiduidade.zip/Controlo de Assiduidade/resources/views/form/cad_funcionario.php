<!DOCTYPE>
<html>
<head>
 <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
    <link href="offcanvas.css" rel="stylesheet">
   
  <link href="dashboard.css" rel="stylesheet">
</head>
    <body>
        <div class="jumbotron ">
        <div class="container py-5" >
           
          
                 

               <div class="row">
                <div class="col-md-6 offset-md-3">
   <!-- form card register -->
                    <div class="card card-outline-secondary">
                        <div class="card-header">
                            <h3 class="mb-0">Ficha de funcionário</h3>
                        </div>
                        <div class="card-body">
                            <form class="form" role="form" autocomplete="off" method="post" action="{{url('')}}">
                                <div class="form-group">
                                    <label for="Nome">Nome</label>
                                    <input type="text" name="nome" class="form-control" id="nome" placeholder="Insira o nome" value="" required>
                                    <div class="invalid-feedback">
                                      É necessario o nome.
                                    </div>
                                </div>
                                <div class="form-group">
                                     <label for="exampleInputName">Gênero</label>
                                    <select required id="genero" name="genero" class="form-control" required="">
                                    <option value=""></option>
                                      <option value="Mascolino">Mascolino</option>
                                      <option value="Femenino">Femenino</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                     <label for="exampleInputName">Nascimento</label>  
                                    <input id="nascimento" name="nascimento" placeholder="DD/MM/AAAA" class="form-control input-md" required="" type="date" maxlength="10" OnKeyPress="formatar('##/##/####', this)" onBlur="showhide()" required="">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputName">Departamento</label>
                                    <select required id="departamento" name="Departamento" class="form-control" required="">
                                    <option value=""></option>
                                      <option value="directoria">Directoria</option>
                                      <option value="operacao">Operação</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                     <label for="exampleInputName">Horário</label>  
                                    <input id="horario" name="horario" placeholder="--:--" class="form-control input-md" type="hora" required="">
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-success btn-lg float-right">Registar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                   </div>
            </div>
                    <!-- /form card register -->

 
        
    


</div>
        </div>
    
    
<script src="jq/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>  
 

</body>

</html>