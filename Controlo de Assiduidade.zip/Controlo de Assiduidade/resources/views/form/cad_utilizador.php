<!DOCTYPE>
<html>
<head>
 <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
    <link href="offcanvas.css" rel="stylesheet">
   
  <link href="dashboard.css" rel="stylesheet">
</head>
    <body>
        <div class="jumbotron ">
        <div class="container py-5" >
           
          
                 

               <div class="row">
                <div class="col-md-6 offset-md-3">
   <!-- form card register -->
                    <div class="card card-outline-secondary">
                        <div class="card-header">
                            <h3 class="mb-0">Criar utilizador</h3>
                        </div>
                        <div class="card-body">
                            <form class="form" role="form" autocomplete="off">
                                <div class="form-group">
                                    <label for="Nome">nome</label>
                                    <input type="text" name="nome" class="form-control" id="nome" placeholder="Insira o nome " value="" required>
                                    <div class="invalid-feedback">
                                      É necessario o nome do chef de posto.
                                    </div>
                                </div>
                                 <div class="form-group">
                                    <label>Password</label>
                                    <input type="password" class="form-control" id="pwd1" required="" autocomplete="new-password">
                                    <div class="invalid-feedback">Please enter a password</div>
                                </div>
                                <div class="form-group">
                                     <label for="exampleInputName">Departamento</label>  
                                    <select required  id="departamento" name="departamento" placeholder="Nome do departameno" class="form-control input-md" type="name" required="">
                                     
                                    <option value=""></option>
                                      <option value="Mascolino">Directoria</option>
                                      <option value="Femenino">Operação</option>
                                    </select>
                                </div>
                                
                                  <div class="form-group">
                                     <label for="exampleInputName">Tipo de utilizador</label>  
                                    <select required  id="tipo" name="tipo" placeholder="Tipo de utilizador" class="form-control input-md" type="name" required="">
                                     
                                      <option value="consulta">Consulta</option>
                                      <option value="consulta_edicao"> Consulta e edição</option>
                                    </select>
                                </div>
                                
                                <div class="form-group">
                                    <button type="submit" class="btn btn-success btn-lg float-right">Registar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                   </div>
            </div>
                    <!-- /form card register -->

 
        
    


</div>
        </div>
    
    
<script src="jq/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>  
 

</body>

</html>