@extends('menu')
@section('conteudo')
<!-- ROW 1 -->
<div class="row marow service-box">
    <div class="col-md-12 ">
        <!-- BLOCK START-->
        <div class="panel panel- panel-info">
            <div class="panel-heading">
                <h1 class="panel-title">Nova Empresa </h1>
            </div>
            <div class="panel-body">
                 @if(session()->has('mensagem_sucesso'))
                    <div class=" alert alert-success">{{session('mensagem_sucesso')}}
                    </div>
                @endif
                <div class="col-md-6">
                        {{ Form::open(['url' => 'enviar']) }}
                        <div class="form-group">
                            <label for="Nome">Nome</label>
                            <input type="text" name="nome" class="form-control" id="nome" placeholder="Insira o nome" value="" required>
                            
                        </div>
                         <div class="form-group">
                            <label for="Nome">NIF</label>
                            <input type="text" name="nif" class="form-control" id="nif" placeholder="Insira o NIF" value="" required>
                            
                        </div>
                        <div class="form-group">
                            <label for="Nome">Espaço fiscal</label>
                            <select>
                                <option>
                                    Angola
                                </option>
                                <option>
                                    SADC
                                </option>
                                <option>
                                    Europa
                                </option>
                            </select>
                        </div>
                          <div class="form-group">
                            <label for="Nome">Logotipo</label>
                            <input type="file" name="logotipo" class="form-control" id="logotipo" placeholder="Logotipo" value="" required >
                        </div>
                        

                        <div class="form-actions right margin-bottom-10">
                            <button type="reset" class="btn btn-danger btn-lg float-right">Limpar</button>
                            <button type="submit" class="btn btn-success btn-lg float-right">Salvar</button>

            </div>

                    {{Form::close()}}
        </div>

    </div>

</div>


</div>
</div>



@endsection





