@extends('menu')
@section('conteudo')
    <div class="row marow service-box">
        <div class="col-md-12 ">
            <!-- BLOCK START-->
            <div class="panel panel- panel-info">
                <div class="panel-heading">
                    <h1 class="panel-title">Lista de funcionarios </h1>
                </div>
                <div class="panel-body">
                    <div class="card mb-3">
                        <div class="card-header">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                    <tr>
                                        <div class="col-sm-12 input-group">
                                            <form method="post" action="{{url('pesquisar')}}" >
                                                {{ csrf_field() }}
                                                <input type="search" required id="nome" name="nome" class="form-control" style="width: 250px;" placeholder="pesquise..">
                                                <button class="btn btn-default" type="submit">Pesquise</button>
                                            </form>
                                        </div>
                                            <div class="col-sm-12">



                                        </div>

                                        <br>
                                        <th>id funcionario</th>
                                        <th>Nome Funcionario</th>
                                          <th>Genero</th>
                                        <th>Departamento</th>
                                        <th>Horario</th>
                                        <th>Editar</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($funcionario as $funcionario)
                                    <tr>
                                        <td>{{$funcionario->id_funcionario}}</td>
                                        <td>{{$funcionario->nome}}</td>
                                        <td>{{$funcionario->genero}}</td>
                                        <td>{{$funcionario->departamento}}</td>
                                        <td>{{$funcionario->horario}}</td>
                                        <td><a class="btn btn-instagram" href="editar/{{$funcionario->id_funcionario}}">Editar</a></td>
                                    </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>

@endsection