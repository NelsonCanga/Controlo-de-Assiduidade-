@extends('menu')

@section('conteudo')
    <div class="row marow service-box">
        <div class="col-md-12 ">
            <!-- BLOCK START-->
            <div class="panel panel- panel-info">
                <div class="panel-heading">
                    <h1 class="panel-title">Novo Departamento </h1>
                </div>
                <div class="panel-body">
                    @if(session()->has('mensagem_sucesso'))
                        <div class=" alert alert-success  ">{{session('mensagem_sucesso')}}
                        </div>
                    @endif
                    <div class="col-md-6">

                    {{ Form::open(['url' => 'departamento']) }}
        <div class="form-group">
            <label for="Nome">Chefe de departamento</label>
            <input type="text" name="nome" class="form-control" id="nome" placeholder="Insira o nome do chef de departamento" value="" required>
            <div class="invalid-feedback">
                É necessario o nome do chef de departamento.
            </div>
        </div>

        <div class="form-group">
            <label for="exampleInputName">Nome do departamento</label>
            <input id="departamento" name="departamento" placeholder="Nome do departameno" class="form-control input-md" type="name" required="">
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-success btn-lg float-right">Registar</button>
        </div>
    {{Form::close()}}
                    </div>
                </div>
            </div>
        </div>
    </div>


@endsection